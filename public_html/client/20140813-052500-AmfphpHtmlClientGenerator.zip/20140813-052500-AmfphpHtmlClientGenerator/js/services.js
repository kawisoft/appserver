var amfphp;
if(!amfphp){
	amfphp = {};
}

amfphp.services = {};

/**
 * set by default to server url with which the code was generated. The contentType parameter is to make sure the server interprets the request as JSON
 * */
amfphp.entryPointUrl = "http://localhost:8000/BackOffice/../gway.php?contentType=application/json";

/** 
*   Description of settings
*  
*   @author kwaku
*   */
amfphp.services.Address = {};


/** 
*   Assign a value to an attribute.
*  
*   @param string $name Name of the attribute
*   @param mixed &$value Value of the attribute
*   @return mixed the attribute value
*   */
amfphp.services.Address.assign_attribute = function(onSuccess, onError, name, value){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"assign_attribute","parameters":[name, value]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieves an attribute's value or a relationship object based on the name passed. If the attribute
*   accessed is 'id' then it will return the model's primary key no matter what the actual attribute name is
*   for the primary key.
*  
*   @param string $name Name of an attribute
*   @return mixed The value of the attribute
*   @throws {@link UndefinedPropertyException} if name could not be resolved to an attribute, relationship, ...
*   */
amfphp.services.Address.read_attribute = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"read_attribute","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Flags an attribute as dirty.
*  
*   @param string $name Attribute name
*   */
amfphp.services.Address.flag_dirty = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"flag_dirty","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns hash of attributes that have been modified since loading the model.
*  
*   @return mixed null if no dirty attributes otherwise returns array of dirty attributes.
*   */
amfphp.services.Address.dirty_attributes = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"dirty_attributes","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Check if a particular attribute has been modified since loading the model.
*   @param string $attributeName of the attribute
*   @return boolean TRUE if it has been modified.
*   */
amfphp.services.Address.attribute_is_dirty = function(onSuccess, onError, attribute){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"attribute_is_dirty","parameters":[attribute]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a copy of the model's attributes hash.
*  
*   @return array A copy of the model's attribute data
*   */
amfphp.services.Address.attributes = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"attributes","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieve the primary key name.
*  
*   @param boolean Set to true to return the first value in the pk array only
*   @return string The primary key for the model
*   */
amfphp.services.Address.get_primary_key = function(onSuccess, onError, first){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"get_primary_key","parameters":[first]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns the actual attribute name if $name is aliased.
*  
*   @param string $name An attribute name
*   @return string
*   */
amfphp.services.Address.get_real_attribute_name = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"get_real_attribute_name","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns array of validator data for this Model.
*  
*   Will return an array looking like:
*  
*   <code>
*   array(
*     'name' => array(
*   array('validator' => 'validates_presence_of'),
*   array('validator' => 'validates_inclusion_of', 'in' => array('Bob','Joe','John')),
*     'password' => array(
*   array('validator' => 'validates_length_of', 'minimum' => 6))
*     )
*   );
*   </code>
*  
*   @return array An array containing validator data for this model.
*   */
amfphp.services.Address.get_validation_rules = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"get_validation_rules","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an associative array containing values for all the attributes in $attributes
*  
*   @param array $attributes Array containing attribute names
*   @return array A hash containing $name => $value
*   */
amfphp.services.Address.get_values_for = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"get_values_for","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieves the name of the table for this Model.
*  
*   @return string
*   */
amfphp.services.Address.table_name = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"table_name","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if the model is in read-only mode.
*  
*   @return boolean
*   */
amfphp.services.Address.is_readonly = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"is_readonly","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if the model is a new record.
*  
*   @return boolean
*   */
amfphp.services.Address.is_new_record = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"is_new_record","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Flag model as readonly.
*  
*   @param boolean $readonly Set to true to put the model into readonly mode
*   */
amfphp.services.Address.readonly = function(onSuccess, onError, readonly){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"readonly","parameters":[readonly]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieve the connection for this model.
*  
*   @return Connection
*   */
amfphp.services.Address.connection = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"connection","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Re-establishes the database connection with a new connection.
*  
*   @return Connection
*   */
amfphp.services.Address.reestablish_connection = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"reestablish_connection","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns the {@link Table} object for this model.
*  
*   Be sure to call in static scoping: static::table()
*  
*   @return Table
*   */
amfphp.services.Address.table = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"table","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Creates a model and saves it to the database.
*  
*   @param array $attributes Array of the models attributes
*   @param boolean $validate True if the validators should be run
*   @param boolean $guard_attributes Set to true to guard protected/non-accessible attributes
*   @return Model
*   */
amfphp.services.Address.create = function(onSuccess, onError, attributes, validate, guard_attributes){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"create","parameters":[attributes, validate, guard_attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Save the model to the database.
*  
*   This function will automatically determine if an INSERT or UPDATE needs to occur.
*   If a validation or a callback for this model returns false, then the model will
*   not be saved and this will return false.
*  
*   If saving an existing model only data that has changed will be saved.
*  
*   @param boolean $validate Set to true or false depending on if you want the validators to run or not
*   @return boolean True if the model was saved to the database otherwise false
*   */
amfphp.services.Address.save = function(onSuccess, onError, validate){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"save","parameters":[validate]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Deletes records matching conditions in $options
*  
*   Does not instantiate models and therefore does not invoke callbacks
*  
*   Delete all using a hash:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => array('name' => 'Tito')));
*   </code>
*  
*   Delete all using an array:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => array('name = ?', 'Tito')));
*   </code>
*  
*   Delete all using a string:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => 'name = "Tito"));
*   </code>
*  
*   An options array takes the following parameters:
*  
*   <ul>
*   <li><b>conditions:</b> Conditions using a string/hash/array</li>
*   <li><b>limit:</b> Limit number of records to delete (MySQL & Sqlite only)</li>
*   <li><b>order:</b> A SQL fragment for ordering such as: 'name asc', 'id desc, name asc' (MySQL & Sqlite only)</li>
*   </ul>
*  
*   @params array $options
*   return integer Number of rows affected
*   */
amfphp.services.Address.delete_all = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"delete_all","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates records using set in $options
*  
*   Does not instantiate models and therefore does not invoke callbacks
*  
*   Update all using a hash:
*  
*   <code>
*   YourModel::update_all(array('set' => array('name' => "Bob")));
*   </code>
*  
*   Update all using a string:
*  
*   <code>
*   YourModel::update_all(array('set' => 'name = "Bob"'));
*   </code>
*  
*   An options array takes the following parameters:
*  
*   <ul>
*   <li><b>set:</b> String/hash of field names and their values to be updated with
*   <li><b>conditions:</b> Conditions using a string/hash/array</li>
*   <li><b>limit:</b> Limit number of records to update (MySQL & Sqlite only)</li>
*   <li><b>order:</b> A SQL fragment for ordering such as: 'name asc', 'id desc, name asc' (MySQL & Sqlite only)</li>
*   </ul>
*  
*   @params array $options
*   return integer Number of rows affected
*   */
amfphp.services.Address.update_all = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"update_all","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Deletes this model from the database and returns true if successful.
*  
*   @return boolean
*   */
amfphp.services.Address.delete = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"delete","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/**  */
amfphp.services.Address.remove_from_cache = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"remove_from_cache","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper that creates an array of values for the primary key(s).
*  
*   @return array An array in the form array(key_name => value, ...)
*   */
amfphp.services.Address.values_for_pk = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"values_for_pk","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper to return a hash of values for the specified attributes.
*  
*   @param array $attribute_names Array of attribute names
*   @return array An array in the form array(name => value, ...)
*   */
amfphp.services.Address.values_for = function(onSuccess, onError, attribute_names){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"values_for","parameters":[attribute_names]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns true if the model has been modified.
*  
*   @return boolean true if modified
*   */
amfphp.services.Address.is_dirty = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"is_dirty","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Run validations on model and returns whether or not model passed validation.
*  
*   @see is_invalid
*   @return boolean
*   */
amfphp.services.Address.is_valid = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"is_valid","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Runs validations and returns true if invalid.
*  
*   @see is_valid
*   @return boolean
*   */
amfphp.services.Address.is_invalid = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"is_invalid","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates a model's timestamps.
*   */
amfphp.services.Address.set_timestamps = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"set_timestamps","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Mass update the model with an array of attribute data and saves to the database.
*  
*   @param array $attributes An attribute data array in the form array(name => value, ...)
*   @return boolean True if successfully updated and saved otherwise false
*   */
amfphp.services.Address.update_attributes = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"update_attributes","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates a single attribute and saves the record without going through the normal validation procedure.
*  
*   @param string $name Name of attribute
*   @param mixed $value Value of the attribute
*   @return boolean True if successful otherwise false
*   */
amfphp.services.Address.update_attribute = function(onSuccess, onError, name, value){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"update_attribute","parameters":[name, value]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Mass update the model with data from an attributes hash.
*  
*   Unlike update_attributes() this method only updates the model's data
*   but DOES NOT save it to the database.
*  
*   @see update_attributes
*   @param array $attributes An array containing data to update in the form array(name => value, ...)
*   */
amfphp.services.Address.set_attributes = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"set_attributes","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Add a model to the given named ($name) relationship.
*  
*   @internal This should <strong>only</strong> be used by eager load
*   @param Model $model
*   @param $name of relationship for this table
*   @return void
*   */
amfphp.services.Address.set_relationship_from_eager_load = function(onSuccess, onError, model, name){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"set_relationship_from_eager_load","parameters":[model, name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Reloads the attributes and relationships of this object from the database.
*  
*   @return Model
*   */
amfphp.services.Address.reload = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"reload","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Resets the dirty array.
*  
*   @see dirty_attributes
*   */
amfphp.services.Address.reset_dirty = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"reset_dirty","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('all').
*  
*   @see find
*   @return array array of records found
*   */
amfphp.services.Address.all = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"all","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Get a count of qualifying records.
*  
*   <code>
*   YourModel::count(array('conditions' => 'amount > 3.14159265'));
*   </code>
*  
*   @see find
*   @return int Number of records that matched the query
*   */
amfphp.services.Address.count = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"count","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if a record exists.
*  
*   <code>
*   SomeModel::exists(123);
*   SomeModel::exists(array('conditions' => array('id=? and name=?', 123, 'Tito')));
*   SomeModel::exists(array('id' => 123, 'name' => 'Tito'));
*   </code>
*  
*   @see find
*   @return boolean
*   */
amfphp.services.Address.exists = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"exists","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('first').
*  
*   @see find
*   @return Model The first matched record or null if not found
*   */
amfphp.services.Address.first = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"first","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('last')
*  
*   @see find
*   @return Model The last matched record or null if not found
*   */
amfphp.services.Address.last = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"last","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Find records in the database.
*  
*   Finding by the primary key:
*  
*   <code>
*   # queries for the model with id=123
*   YourModel::find(123);
*  
*   # queries for model with id in(1,2,3)
*   YourModel::find(1,2,3);
*  
*   # finding by pk accepts an options array
*   YourModel::find(123,array('order' => 'name desc'));
*   </code>
*  
*   Finding by using a conditions array:
*  
*   <code>
*   YourModel::find('first', array('conditions' => array('name=?','Tito'),
*     'order' => 'name asc'))
*   YourModel::find('all', array('conditions' => 'amount > 3.14159265'));
*   YourModel::find('all', array('conditions' => array('id in(?)', array(1,2,3))));
*   </code>
*  
*   Finding by using a hash:
*  
*   <code>
*   YourModel::find(array('name' => 'Tito', 'id' => 1));
*   YourModel::find('first',array('name' => 'Tito', 'id' => 1));
*   YourModel::find('all',array('name' => 'Tito', 'id' => 1));
*   </code>
*  
*   An options array can take the following parameters:
*  
*   <ul>
*   <li><b>select:</b> A SQL fragment for what fields to return such as: '', 'people.', 'first_name, last_name, id'</li>
*   <li><b>joins:</b> A SQL join fragment such as: 'JOIN roles ON(roles.user_id=user.id)' or a named association on the model</li>
*   <li><b>include:</b> TODO not implemented yet</li>
*   <li><b>conditions:</b> A SQL fragment such as: 'id=1', array('id=1'), array('name=? and id=?','Tito',1), array('name IN(?)', array('Tito','Bob')),
*   array('name' => 'Tito', 'id' => 1)</li>
*   <li><b>limit:</b> Number of records to limit the query to</li>
*   <li><b>offset:</b> The row offset to return results from for the query</li>
*   <li><b>order:</b> A SQL fragment for order such as: 'name asc', 'name asc, id desc'</li>
*   <li><b>readonly:</b> Return all the models in readonly mode</li>
*   <li><b>group:</b> A SQL group by fragment</li>
*   </ul>
*  
*   @throws {@link RecordNotFound} if no options are passed or finding by pk and no records matched
*   @return mixed An array of records found if doing a find_all otherwise a
*     single Model object or null if it wasn't found. NULL is only return when
*     doing a first/last find. If doing an all find and no records matched this
*     will return an empty array.
*   */
amfphp.services.Address.find = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"find","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Finder method which will find by a single or array of primary keys for this model.
*  
*   @see find
*   @param array $values An array containing values for the pk
*   @param array $options An options array
*   @return Model
*   @throws {@link RecordNotFound} if a record could not be found
*   */
amfphp.services.Address.find_by_pk = function(onSuccess, onError, values, options){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"find_by_pk","parameters":[values, options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Find using a raw SELECT query.
*  
*   <code>
*   YourModel::find_by_sql("SELECT  FROM people WHERE name=?",array('Tito'));
*   YourModel::find_by_sql("SELECT  FROM people WHERE name='Tito'");
*   </code>
*  
*   @param string $sql The raw SELECT query
*   @param array $values An array of values for any parameters that needs to be bound
*   @return array An array of models
*   */
amfphp.services.Address.find_by_sql = function(onSuccess, onError, sql, values){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"find_by_sql","parameters":[sql, values]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper method to run arbitrary queries against the model's database connection.
*  
*   @param string $sql SQL to execute
*   @param array $values Bind values, if any, for the query
*   @return object A PDOStatement object
*   */
amfphp.services.Address.query = function(onSuccess, onError, sql, values){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"query","parameters":[sql, values]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determines if the specified array is a valid ActiveRecord options array.
*  
*   @param array $array An options array
*   @param bool $throw True to throw an exception if not valid
*   @return boolean True if valid otherwise valse
*   @throws {@link ActiveRecordException} if the array contained any invalid options
*   */
amfphp.services.Address.is_options_hash = function(onSuccess, onError, array, throw){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"is_options_hash","parameters":[array, throw]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a hash containing the names => values of the primary key.
*  
*   @internal This needs to eventually support composite keys.
*   @param mixed $args Primary key value(s)
*   @return array An array in the form array(name => value, ...)
*   */
amfphp.services.Address.pk_conditions = function(onSuccess, onError, args){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"pk_conditions","parameters":[args]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Pulls out the options hash from $array if any.
*  
*   @internal DO NOT remove the reference on $array.
*   @param array &$array An array
*   @return array A valid options array
*   */
amfphp.services.Address.extract_and_validate_options = function(onSuccess, onError, array){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"extract_and_validate_options","parameters":[array]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a JSON representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for json serialization (see {@link Serialization} for valid options)
*   @return string JSON representation of the model
*   */
amfphp.services.Address.to_json = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"to_json","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an XML representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for xml serialization (see {@link Serialization} for valid options)
*   @return string XML representation of the model
*   */
amfphp.services.Address.to_xml = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"to_xml","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*     Returns an CSV representation of this model.
*     Can take optional delimiter and enclosure
*     (defaults are , and double quotes)
*    
*     Ex:
*     <code>
*     ActiveRecord\CsvSerializer::$delimiter=';';
*     ActiveRecord\CsvSerializer::$enclosure='';
*     YourModel::find('first')->to_csv(array('only'=>array('name','level')));
*     returns: Joe,2
*    
*     YourModel::find('first')->to_csv(array('only_header'=>true,'only'=>array('name','level')));
*     returns: name,level
*     </code>
*    
*     @see Serialization
*     @param array $options An array containing options for csv serialization (see {@link Serialization} for valid options)
*     @return string CSV representation of the model
*     */
amfphp.services.Address.to_csv = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"to_csv","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an Array representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for json serialization (see {@link Serialization} for valid options)
*   @return array Array representation of the model
*   */
amfphp.services.Address.to_array = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"to_array","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Executes a block of code inside a database transaction.
*  
*   <code>
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*   });
*   </code>
*  
*   If an exception is thrown inside the closure the transaction will
*   automatically be rolled back. You can also return false from your
*   closure to cause a rollback:
*  
*   <code>
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*     throw new Exception("rollback!");
*   });
*  
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*     return false; # rollback!
*   });
*   </code>
*  
*   @param callable $closure The closure to execute. To cause a rollback have your closure return false or throw an exception.
*   @return boolean True if the transaction was committed, False if rolled back.
*   */
amfphp.services.Address.transaction = function(onSuccess, onError, closure){
	var callData = JSON.stringify({"serviceName":"Address", "methodName":"transaction","parameters":[closure]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Description of settings
*  
*   @author kwaku
*   */
amfphp.services.Group = {};


/**  */
amfphp.services.Group.dropGroupList = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"dropGroupList","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/**  */
amfphp.services.Group.getName = function(onSuccess, onError, id){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"getName","parameters":[id]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Assign a value to an attribute.
*  
*   @param string $name Name of the attribute
*   @param mixed &$value Value of the attribute
*   @return mixed the attribute value
*   */
amfphp.services.Group.assign_attribute = function(onSuccess, onError, name, value){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"assign_attribute","parameters":[name, value]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieves an attribute's value or a relationship object based on the name passed. If the attribute
*   accessed is 'id' then it will return the model's primary key no matter what the actual attribute name is
*   for the primary key.
*  
*   @param string $name Name of an attribute
*   @return mixed The value of the attribute
*   @throws {@link UndefinedPropertyException} if name could not be resolved to an attribute, relationship, ...
*   */
amfphp.services.Group.read_attribute = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"read_attribute","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Flags an attribute as dirty.
*  
*   @param string $name Attribute name
*   */
amfphp.services.Group.flag_dirty = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"flag_dirty","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns hash of attributes that have been modified since loading the model.
*  
*   @return mixed null if no dirty attributes otherwise returns array of dirty attributes.
*   */
amfphp.services.Group.dirty_attributes = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"dirty_attributes","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Check if a particular attribute has been modified since loading the model.
*   @param string $attributeName of the attribute
*   @return boolean TRUE if it has been modified.
*   */
amfphp.services.Group.attribute_is_dirty = function(onSuccess, onError, attribute){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"attribute_is_dirty","parameters":[attribute]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a copy of the model's attributes hash.
*  
*   @return array A copy of the model's attribute data
*   */
amfphp.services.Group.attributes = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"attributes","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieve the primary key name.
*  
*   @param boolean Set to true to return the first value in the pk array only
*   @return string The primary key for the model
*   */
amfphp.services.Group.get_primary_key = function(onSuccess, onError, first){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"get_primary_key","parameters":[first]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns the actual attribute name if $name is aliased.
*  
*   @param string $name An attribute name
*   @return string
*   */
amfphp.services.Group.get_real_attribute_name = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"get_real_attribute_name","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns array of validator data for this Model.
*  
*   Will return an array looking like:
*  
*   <code>
*   array(
*     'name' => array(
*   array('validator' => 'validates_presence_of'),
*   array('validator' => 'validates_inclusion_of', 'in' => array('Bob','Joe','John')),
*     'password' => array(
*   array('validator' => 'validates_length_of', 'minimum' => 6))
*     )
*   );
*   </code>
*  
*   @return array An array containing validator data for this model.
*   */
amfphp.services.Group.get_validation_rules = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"get_validation_rules","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an associative array containing values for all the attributes in $attributes
*  
*   @param array $attributes Array containing attribute names
*   @return array A hash containing $name => $value
*   */
amfphp.services.Group.get_values_for = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"get_values_for","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieves the name of the table for this Model.
*  
*   @return string
*   */
amfphp.services.Group.table_name = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"table_name","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if the model is in read-only mode.
*  
*   @return boolean
*   */
amfphp.services.Group.is_readonly = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"is_readonly","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if the model is a new record.
*  
*   @return boolean
*   */
amfphp.services.Group.is_new_record = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"is_new_record","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Flag model as readonly.
*  
*   @param boolean $readonly Set to true to put the model into readonly mode
*   */
amfphp.services.Group.readonly = function(onSuccess, onError, readonly){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"readonly","parameters":[readonly]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieve the connection for this model.
*  
*   @return Connection
*   */
amfphp.services.Group.connection = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"connection","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Re-establishes the database connection with a new connection.
*  
*   @return Connection
*   */
amfphp.services.Group.reestablish_connection = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"reestablish_connection","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns the {@link Table} object for this model.
*  
*   Be sure to call in static scoping: static::table()
*  
*   @return Table
*   */
amfphp.services.Group.table = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"table","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Creates a model and saves it to the database.
*  
*   @param array $attributes Array of the models attributes
*   @param boolean $validate True if the validators should be run
*   @param boolean $guard_attributes Set to true to guard protected/non-accessible attributes
*   @return Model
*   */
amfphp.services.Group.create = function(onSuccess, onError, attributes, validate, guard_attributes){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"create","parameters":[attributes, validate, guard_attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Save the model to the database.
*  
*   This function will automatically determine if an INSERT or UPDATE needs to occur.
*   If a validation or a callback for this model returns false, then the model will
*   not be saved and this will return false.
*  
*   If saving an existing model only data that has changed will be saved.
*  
*   @param boolean $validate Set to true or false depending on if you want the validators to run or not
*   @return boolean True if the model was saved to the database otherwise false
*   */
amfphp.services.Group.save = function(onSuccess, onError, validate){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"save","parameters":[validate]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Deletes records matching conditions in $options
*  
*   Does not instantiate models and therefore does not invoke callbacks
*  
*   Delete all using a hash:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => array('name' => 'Tito')));
*   </code>
*  
*   Delete all using an array:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => array('name = ?', 'Tito')));
*   </code>
*  
*   Delete all using a string:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => 'name = "Tito"));
*   </code>
*  
*   An options array takes the following parameters:
*  
*   <ul>
*   <li><b>conditions:</b> Conditions using a string/hash/array</li>
*   <li><b>limit:</b> Limit number of records to delete (MySQL & Sqlite only)</li>
*   <li><b>order:</b> A SQL fragment for ordering such as: 'name asc', 'id desc, name asc' (MySQL & Sqlite only)</li>
*   </ul>
*  
*   @params array $options
*   return integer Number of rows affected
*   */
amfphp.services.Group.delete_all = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"delete_all","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates records using set in $options
*  
*   Does not instantiate models and therefore does not invoke callbacks
*  
*   Update all using a hash:
*  
*   <code>
*   YourModel::update_all(array('set' => array('name' => "Bob")));
*   </code>
*  
*   Update all using a string:
*  
*   <code>
*   YourModel::update_all(array('set' => 'name = "Bob"'));
*   </code>
*  
*   An options array takes the following parameters:
*  
*   <ul>
*   <li><b>set:</b> String/hash of field names and their values to be updated with
*   <li><b>conditions:</b> Conditions using a string/hash/array</li>
*   <li><b>limit:</b> Limit number of records to update (MySQL & Sqlite only)</li>
*   <li><b>order:</b> A SQL fragment for ordering such as: 'name asc', 'id desc, name asc' (MySQL & Sqlite only)</li>
*   </ul>
*  
*   @params array $options
*   return integer Number of rows affected
*   */
amfphp.services.Group.update_all = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"update_all","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Deletes this model from the database and returns true if successful.
*  
*   @return boolean
*   */
amfphp.services.Group.delete = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"delete","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/**  */
amfphp.services.Group.remove_from_cache = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"remove_from_cache","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper that creates an array of values for the primary key(s).
*  
*   @return array An array in the form array(key_name => value, ...)
*   */
amfphp.services.Group.values_for_pk = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"values_for_pk","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper to return a hash of values for the specified attributes.
*  
*   @param array $attribute_names Array of attribute names
*   @return array An array in the form array(name => value, ...)
*   */
amfphp.services.Group.values_for = function(onSuccess, onError, attribute_names){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"values_for","parameters":[attribute_names]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns true if the model has been modified.
*  
*   @return boolean true if modified
*   */
amfphp.services.Group.is_dirty = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"is_dirty","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Run validations on model and returns whether or not model passed validation.
*  
*   @see is_invalid
*   @return boolean
*   */
amfphp.services.Group.is_valid = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"is_valid","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Runs validations and returns true if invalid.
*  
*   @see is_valid
*   @return boolean
*   */
amfphp.services.Group.is_invalid = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"is_invalid","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates a model's timestamps.
*   */
amfphp.services.Group.set_timestamps = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"set_timestamps","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Mass update the model with an array of attribute data and saves to the database.
*  
*   @param array $attributes An attribute data array in the form array(name => value, ...)
*   @return boolean True if successfully updated and saved otherwise false
*   */
amfphp.services.Group.update_attributes = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"update_attributes","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates a single attribute and saves the record without going through the normal validation procedure.
*  
*   @param string $name Name of attribute
*   @param mixed $value Value of the attribute
*   @return boolean True if successful otherwise false
*   */
amfphp.services.Group.update_attribute = function(onSuccess, onError, name, value){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"update_attribute","parameters":[name, value]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Mass update the model with data from an attributes hash.
*  
*   Unlike update_attributes() this method only updates the model's data
*   but DOES NOT save it to the database.
*  
*   @see update_attributes
*   @param array $attributes An array containing data to update in the form array(name => value, ...)
*   */
amfphp.services.Group.set_attributes = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"set_attributes","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Add a model to the given named ($name) relationship.
*  
*   @internal This should <strong>only</strong> be used by eager load
*   @param Model $model
*   @param $name of relationship for this table
*   @return void
*   */
amfphp.services.Group.set_relationship_from_eager_load = function(onSuccess, onError, model, name){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"set_relationship_from_eager_load","parameters":[model, name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Reloads the attributes and relationships of this object from the database.
*  
*   @return Model
*   */
amfphp.services.Group.reload = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"reload","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Resets the dirty array.
*  
*   @see dirty_attributes
*   */
amfphp.services.Group.reset_dirty = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"reset_dirty","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('all').
*  
*   @see find
*   @return array array of records found
*   */
amfphp.services.Group.all = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"all","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Get a count of qualifying records.
*  
*   <code>
*   YourModel::count(array('conditions' => 'amount > 3.14159265'));
*   </code>
*  
*   @see find
*   @return int Number of records that matched the query
*   */
amfphp.services.Group.count = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"count","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if a record exists.
*  
*   <code>
*   SomeModel::exists(123);
*   SomeModel::exists(array('conditions' => array('id=? and name=?', 123, 'Tito')));
*   SomeModel::exists(array('id' => 123, 'name' => 'Tito'));
*   </code>
*  
*   @see find
*   @return boolean
*   */
amfphp.services.Group.exists = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"exists","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('first').
*  
*   @see find
*   @return Model The first matched record or null if not found
*   */
amfphp.services.Group.first = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"first","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('last')
*  
*   @see find
*   @return Model The last matched record or null if not found
*   */
amfphp.services.Group.last = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"last","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Find records in the database.
*  
*   Finding by the primary key:
*  
*   <code>
*   # queries for the model with id=123
*   YourModel::find(123);
*  
*   # queries for model with id in(1,2,3)
*   YourModel::find(1,2,3);
*  
*   # finding by pk accepts an options array
*   YourModel::find(123,array('order' => 'name desc'));
*   </code>
*  
*   Finding by using a conditions array:
*  
*   <code>
*   YourModel::find('first', array('conditions' => array('name=?','Tito'),
*     'order' => 'name asc'))
*   YourModel::find('all', array('conditions' => 'amount > 3.14159265'));
*   YourModel::find('all', array('conditions' => array('id in(?)', array(1,2,3))));
*   </code>
*  
*   Finding by using a hash:
*  
*   <code>
*   YourModel::find(array('name' => 'Tito', 'id' => 1));
*   YourModel::find('first',array('name' => 'Tito', 'id' => 1));
*   YourModel::find('all',array('name' => 'Tito', 'id' => 1));
*   </code>
*  
*   An options array can take the following parameters:
*  
*   <ul>
*   <li><b>select:</b> A SQL fragment for what fields to return such as: '', 'people.', 'first_name, last_name, id'</li>
*   <li><b>joins:</b> A SQL join fragment such as: 'JOIN roles ON(roles.user_id=user.id)' or a named association on the model</li>
*   <li><b>include:</b> TODO not implemented yet</li>
*   <li><b>conditions:</b> A SQL fragment such as: 'id=1', array('id=1'), array('name=? and id=?','Tito',1), array('name IN(?)', array('Tito','Bob')),
*   array('name' => 'Tito', 'id' => 1)</li>
*   <li><b>limit:</b> Number of records to limit the query to</li>
*   <li><b>offset:</b> The row offset to return results from for the query</li>
*   <li><b>order:</b> A SQL fragment for order such as: 'name asc', 'name asc, id desc'</li>
*   <li><b>readonly:</b> Return all the models in readonly mode</li>
*   <li><b>group:</b> A SQL group by fragment</li>
*   </ul>
*  
*   @throws {@link RecordNotFound} if no options are passed or finding by pk and no records matched
*   @return mixed An array of records found if doing a find_all otherwise a
*     single Model object or null if it wasn't found. NULL is only return when
*     doing a first/last find. If doing an all find and no records matched this
*     will return an empty array.
*   */
amfphp.services.Group.find = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"find","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Finder method which will find by a single or array of primary keys for this model.
*  
*   @see find
*   @param array $values An array containing values for the pk
*   @param array $options An options array
*   @return Model
*   @throws {@link RecordNotFound} if a record could not be found
*   */
amfphp.services.Group.find_by_pk = function(onSuccess, onError, values, options){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"find_by_pk","parameters":[values, options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Find using a raw SELECT query.
*  
*   <code>
*   YourModel::find_by_sql("SELECT  FROM people WHERE name=?",array('Tito'));
*   YourModel::find_by_sql("SELECT  FROM people WHERE name='Tito'");
*   </code>
*  
*   @param string $sql The raw SELECT query
*   @param array $values An array of values for any parameters that needs to be bound
*   @return array An array of models
*   */
amfphp.services.Group.find_by_sql = function(onSuccess, onError, sql, values){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"find_by_sql","parameters":[sql, values]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper method to run arbitrary queries against the model's database connection.
*  
*   @param string $sql SQL to execute
*   @param array $values Bind values, if any, for the query
*   @return object A PDOStatement object
*   */
amfphp.services.Group.query = function(onSuccess, onError, sql, values){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"query","parameters":[sql, values]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determines if the specified array is a valid ActiveRecord options array.
*  
*   @param array $array An options array
*   @param bool $throw True to throw an exception if not valid
*   @return boolean True if valid otherwise valse
*   @throws {@link ActiveRecordException} if the array contained any invalid options
*   */
amfphp.services.Group.is_options_hash = function(onSuccess, onError, array, throw){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"is_options_hash","parameters":[array, throw]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a hash containing the names => values of the primary key.
*  
*   @internal This needs to eventually support composite keys.
*   @param mixed $args Primary key value(s)
*   @return array An array in the form array(name => value, ...)
*   */
amfphp.services.Group.pk_conditions = function(onSuccess, onError, args){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"pk_conditions","parameters":[args]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Pulls out the options hash from $array if any.
*  
*   @internal DO NOT remove the reference on $array.
*   @param array &$array An array
*   @return array A valid options array
*   */
amfphp.services.Group.extract_and_validate_options = function(onSuccess, onError, array){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"extract_and_validate_options","parameters":[array]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a JSON representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for json serialization (see {@link Serialization} for valid options)
*   @return string JSON representation of the model
*   */
amfphp.services.Group.to_json = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"to_json","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an XML representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for xml serialization (see {@link Serialization} for valid options)
*   @return string XML representation of the model
*   */
amfphp.services.Group.to_xml = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"to_xml","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*     Returns an CSV representation of this model.
*     Can take optional delimiter and enclosure
*     (defaults are , and double quotes)
*    
*     Ex:
*     <code>
*     ActiveRecord\CsvSerializer::$delimiter=';';
*     ActiveRecord\CsvSerializer::$enclosure='';
*     YourModel::find('first')->to_csv(array('only'=>array('name','level')));
*     returns: Joe,2
*    
*     YourModel::find('first')->to_csv(array('only_header'=>true,'only'=>array('name','level')));
*     returns: name,level
*     </code>
*    
*     @see Serialization
*     @param array $options An array containing options for csv serialization (see {@link Serialization} for valid options)
*     @return string CSV representation of the model
*     */
amfphp.services.Group.to_csv = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"to_csv","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an Array representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for json serialization (see {@link Serialization} for valid options)
*   @return array Array representation of the model
*   */
amfphp.services.Group.to_array = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"to_array","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Executes a block of code inside a database transaction.
*  
*   <code>
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*   });
*   </code>
*  
*   If an exception is thrown inside the closure the transaction will
*   automatically be rolled back. You can also return false from your
*   closure to cause a rollback:
*  
*   <code>
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*     throw new Exception("rollback!");
*   });
*  
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*     return false; # rollback!
*   });
*   </code>
*  
*   @param callable $closure The closure to execute. To cause a rollback have your closure return false or throw an exception.
*   @return boolean True if the transaction was committed, False if rolled back.
*   */
amfphp.services.Group.transaction = function(onSuccess, onError, closure){
	var callData = JSON.stringify({"serviceName":"Group", "methodName":"transaction","parameters":[closure]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Description of settings
*  
*   @author kwaku
*   */
amfphp.services.GroupMember = {};


/**  */
amfphp.services.GroupMember.getGroupsByUser = function(onSuccess, onError, user_id){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"getGroupsByUser","parameters":[user_id]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Assign a value to an attribute.
*  
*   @param string $name Name of the attribute
*   @param mixed &$value Value of the attribute
*   @return mixed the attribute value
*   */
amfphp.services.GroupMember.assign_attribute = function(onSuccess, onError, name, value){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"assign_attribute","parameters":[name, value]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieves an attribute's value or a relationship object based on the name passed. If the attribute
*   accessed is 'id' then it will return the model's primary key no matter what the actual attribute name is
*   for the primary key.
*  
*   @param string $name Name of an attribute
*   @return mixed The value of the attribute
*   @throws {@link UndefinedPropertyException} if name could not be resolved to an attribute, relationship, ...
*   */
amfphp.services.GroupMember.read_attribute = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"read_attribute","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Flags an attribute as dirty.
*  
*   @param string $name Attribute name
*   */
amfphp.services.GroupMember.flag_dirty = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"flag_dirty","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns hash of attributes that have been modified since loading the model.
*  
*   @return mixed null if no dirty attributes otherwise returns array of dirty attributes.
*   */
amfphp.services.GroupMember.dirty_attributes = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"dirty_attributes","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Check if a particular attribute has been modified since loading the model.
*   @param string $attributeName of the attribute
*   @return boolean TRUE if it has been modified.
*   */
amfphp.services.GroupMember.attribute_is_dirty = function(onSuccess, onError, attribute){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"attribute_is_dirty","parameters":[attribute]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a copy of the model's attributes hash.
*  
*   @return array A copy of the model's attribute data
*   */
amfphp.services.GroupMember.attributes = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"attributes","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieve the primary key name.
*  
*   @param boolean Set to true to return the first value in the pk array only
*   @return string The primary key for the model
*   */
amfphp.services.GroupMember.get_primary_key = function(onSuccess, onError, first){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"get_primary_key","parameters":[first]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns the actual attribute name if $name is aliased.
*  
*   @param string $name An attribute name
*   @return string
*   */
amfphp.services.GroupMember.get_real_attribute_name = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"get_real_attribute_name","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns array of validator data for this Model.
*  
*   Will return an array looking like:
*  
*   <code>
*   array(
*     'name' => array(
*   array('validator' => 'validates_presence_of'),
*   array('validator' => 'validates_inclusion_of', 'in' => array('Bob','Joe','John')),
*     'password' => array(
*   array('validator' => 'validates_length_of', 'minimum' => 6))
*     )
*   );
*   </code>
*  
*   @return array An array containing validator data for this model.
*   */
amfphp.services.GroupMember.get_validation_rules = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"get_validation_rules","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an associative array containing values for all the attributes in $attributes
*  
*   @param array $attributes Array containing attribute names
*   @return array A hash containing $name => $value
*   */
amfphp.services.GroupMember.get_values_for = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"get_values_for","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieves the name of the table for this Model.
*  
*   @return string
*   */
amfphp.services.GroupMember.table_name = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"table_name","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if the model is in read-only mode.
*  
*   @return boolean
*   */
amfphp.services.GroupMember.is_readonly = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"is_readonly","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if the model is a new record.
*  
*   @return boolean
*   */
amfphp.services.GroupMember.is_new_record = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"is_new_record","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Flag model as readonly.
*  
*   @param boolean $readonly Set to true to put the model into readonly mode
*   */
amfphp.services.GroupMember.readonly = function(onSuccess, onError, readonly){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"readonly","parameters":[readonly]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieve the connection for this model.
*  
*   @return Connection
*   */
amfphp.services.GroupMember.connection = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"connection","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Re-establishes the database connection with a new connection.
*  
*   @return Connection
*   */
amfphp.services.GroupMember.reestablish_connection = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"reestablish_connection","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns the {@link Table} object for this model.
*  
*   Be sure to call in static scoping: static::table()
*  
*   @return Table
*   */
amfphp.services.GroupMember.table = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"table","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Creates a model and saves it to the database.
*  
*   @param array $attributes Array of the models attributes
*   @param boolean $validate True if the validators should be run
*   @param boolean $guard_attributes Set to true to guard protected/non-accessible attributes
*   @return Model
*   */
amfphp.services.GroupMember.create = function(onSuccess, onError, attributes, validate, guard_attributes){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"create","parameters":[attributes, validate, guard_attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Save the model to the database.
*  
*   This function will automatically determine if an INSERT or UPDATE needs to occur.
*   If a validation or a callback for this model returns false, then the model will
*   not be saved and this will return false.
*  
*   If saving an existing model only data that has changed will be saved.
*  
*   @param boolean $validate Set to true or false depending on if you want the validators to run or not
*   @return boolean True if the model was saved to the database otherwise false
*   */
amfphp.services.GroupMember.save = function(onSuccess, onError, validate){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"save","parameters":[validate]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Deletes records matching conditions in $options
*  
*   Does not instantiate models and therefore does not invoke callbacks
*  
*   Delete all using a hash:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => array('name' => 'Tito')));
*   </code>
*  
*   Delete all using an array:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => array('name = ?', 'Tito')));
*   </code>
*  
*   Delete all using a string:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => 'name = "Tito"));
*   </code>
*  
*   An options array takes the following parameters:
*  
*   <ul>
*   <li><b>conditions:</b> Conditions using a string/hash/array</li>
*   <li><b>limit:</b> Limit number of records to delete (MySQL & Sqlite only)</li>
*   <li><b>order:</b> A SQL fragment for ordering such as: 'name asc', 'id desc, name asc' (MySQL & Sqlite only)</li>
*   </ul>
*  
*   @params array $options
*   return integer Number of rows affected
*   */
amfphp.services.GroupMember.delete_all = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"delete_all","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates records using set in $options
*  
*   Does not instantiate models and therefore does not invoke callbacks
*  
*   Update all using a hash:
*  
*   <code>
*   YourModel::update_all(array('set' => array('name' => "Bob")));
*   </code>
*  
*   Update all using a string:
*  
*   <code>
*   YourModel::update_all(array('set' => 'name = "Bob"'));
*   </code>
*  
*   An options array takes the following parameters:
*  
*   <ul>
*   <li><b>set:</b> String/hash of field names and their values to be updated with
*   <li><b>conditions:</b> Conditions using a string/hash/array</li>
*   <li><b>limit:</b> Limit number of records to update (MySQL & Sqlite only)</li>
*   <li><b>order:</b> A SQL fragment for ordering such as: 'name asc', 'id desc, name asc' (MySQL & Sqlite only)</li>
*   </ul>
*  
*   @params array $options
*   return integer Number of rows affected
*   */
amfphp.services.GroupMember.update_all = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"update_all","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Deletes this model from the database and returns true if successful.
*  
*   @return boolean
*   */
amfphp.services.GroupMember.delete = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"delete","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/**  */
amfphp.services.GroupMember.remove_from_cache = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"remove_from_cache","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper that creates an array of values for the primary key(s).
*  
*   @return array An array in the form array(key_name => value, ...)
*   */
amfphp.services.GroupMember.values_for_pk = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"values_for_pk","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper to return a hash of values for the specified attributes.
*  
*   @param array $attribute_names Array of attribute names
*   @return array An array in the form array(name => value, ...)
*   */
amfphp.services.GroupMember.values_for = function(onSuccess, onError, attribute_names){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"values_for","parameters":[attribute_names]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns true if the model has been modified.
*  
*   @return boolean true if modified
*   */
amfphp.services.GroupMember.is_dirty = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"is_dirty","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Run validations on model and returns whether or not model passed validation.
*  
*   @see is_invalid
*   @return boolean
*   */
amfphp.services.GroupMember.is_valid = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"is_valid","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Runs validations and returns true if invalid.
*  
*   @see is_valid
*   @return boolean
*   */
amfphp.services.GroupMember.is_invalid = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"is_invalid","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates a model's timestamps.
*   */
amfphp.services.GroupMember.set_timestamps = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"set_timestamps","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Mass update the model with an array of attribute data and saves to the database.
*  
*   @param array $attributes An attribute data array in the form array(name => value, ...)
*   @return boolean True if successfully updated and saved otherwise false
*   */
amfphp.services.GroupMember.update_attributes = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"update_attributes","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates a single attribute and saves the record without going through the normal validation procedure.
*  
*   @param string $name Name of attribute
*   @param mixed $value Value of the attribute
*   @return boolean True if successful otherwise false
*   */
amfphp.services.GroupMember.update_attribute = function(onSuccess, onError, name, value){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"update_attribute","parameters":[name, value]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Mass update the model with data from an attributes hash.
*  
*   Unlike update_attributes() this method only updates the model's data
*   but DOES NOT save it to the database.
*  
*   @see update_attributes
*   @param array $attributes An array containing data to update in the form array(name => value, ...)
*   */
amfphp.services.GroupMember.set_attributes = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"set_attributes","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Add a model to the given named ($name) relationship.
*  
*   @internal This should <strong>only</strong> be used by eager load
*   @param Model $model
*   @param $name of relationship for this table
*   @return void
*   */
amfphp.services.GroupMember.set_relationship_from_eager_load = function(onSuccess, onError, model, name){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"set_relationship_from_eager_load","parameters":[model, name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Reloads the attributes and relationships of this object from the database.
*  
*   @return Model
*   */
amfphp.services.GroupMember.reload = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"reload","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Resets the dirty array.
*  
*   @see dirty_attributes
*   */
amfphp.services.GroupMember.reset_dirty = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"reset_dirty","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('all').
*  
*   @see find
*   @return array array of records found
*   */
amfphp.services.GroupMember.all = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"all","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Get a count of qualifying records.
*  
*   <code>
*   YourModel::count(array('conditions' => 'amount > 3.14159265'));
*   </code>
*  
*   @see find
*   @return int Number of records that matched the query
*   */
amfphp.services.GroupMember.count = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"count","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if a record exists.
*  
*   <code>
*   SomeModel::exists(123);
*   SomeModel::exists(array('conditions' => array('id=? and name=?', 123, 'Tito')));
*   SomeModel::exists(array('id' => 123, 'name' => 'Tito'));
*   </code>
*  
*   @see find
*   @return boolean
*   */
amfphp.services.GroupMember.exists = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"exists","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('first').
*  
*   @see find
*   @return Model The first matched record or null if not found
*   */
amfphp.services.GroupMember.first = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"first","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('last')
*  
*   @see find
*   @return Model The last matched record or null if not found
*   */
amfphp.services.GroupMember.last = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"last","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Find records in the database.
*  
*   Finding by the primary key:
*  
*   <code>
*   # queries for the model with id=123
*   YourModel::find(123);
*  
*   # queries for model with id in(1,2,3)
*   YourModel::find(1,2,3);
*  
*   # finding by pk accepts an options array
*   YourModel::find(123,array('order' => 'name desc'));
*   </code>
*  
*   Finding by using a conditions array:
*  
*   <code>
*   YourModel::find('first', array('conditions' => array('name=?','Tito'),
*     'order' => 'name asc'))
*   YourModel::find('all', array('conditions' => 'amount > 3.14159265'));
*   YourModel::find('all', array('conditions' => array('id in(?)', array(1,2,3))));
*   </code>
*  
*   Finding by using a hash:
*  
*   <code>
*   YourModel::find(array('name' => 'Tito', 'id' => 1));
*   YourModel::find('first',array('name' => 'Tito', 'id' => 1));
*   YourModel::find('all',array('name' => 'Tito', 'id' => 1));
*   </code>
*  
*   An options array can take the following parameters:
*  
*   <ul>
*   <li><b>select:</b> A SQL fragment for what fields to return such as: '', 'people.', 'first_name, last_name, id'</li>
*   <li><b>joins:</b> A SQL join fragment such as: 'JOIN roles ON(roles.user_id=user.id)' or a named association on the model</li>
*   <li><b>include:</b> TODO not implemented yet</li>
*   <li><b>conditions:</b> A SQL fragment such as: 'id=1', array('id=1'), array('name=? and id=?','Tito',1), array('name IN(?)', array('Tito','Bob')),
*   array('name' => 'Tito', 'id' => 1)</li>
*   <li><b>limit:</b> Number of records to limit the query to</li>
*   <li><b>offset:</b> The row offset to return results from for the query</li>
*   <li><b>order:</b> A SQL fragment for order such as: 'name asc', 'name asc, id desc'</li>
*   <li><b>readonly:</b> Return all the models in readonly mode</li>
*   <li><b>group:</b> A SQL group by fragment</li>
*   </ul>
*  
*   @throws {@link RecordNotFound} if no options are passed or finding by pk and no records matched
*   @return mixed An array of records found if doing a find_all otherwise a
*     single Model object or null if it wasn't found. NULL is only return when
*     doing a first/last find. If doing an all find and no records matched this
*     will return an empty array.
*   */
amfphp.services.GroupMember.find = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"find","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Finder method which will find by a single or array of primary keys for this model.
*  
*   @see find
*   @param array $values An array containing values for the pk
*   @param array $options An options array
*   @return Model
*   @throws {@link RecordNotFound} if a record could not be found
*   */
amfphp.services.GroupMember.find_by_pk = function(onSuccess, onError, values, options){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"find_by_pk","parameters":[values, options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Find using a raw SELECT query.
*  
*   <code>
*   YourModel::find_by_sql("SELECT  FROM people WHERE name=?",array('Tito'));
*   YourModel::find_by_sql("SELECT  FROM people WHERE name='Tito'");
*   </code>
*  
*   @param string $sql The raw SELECT query
*   @param array $values An array of values for any parameters that needs to be bound
*   @return array An array of models
*   */
amfphp.services.GroupMember.find_by_sql = function(onSuccess, onError, sql, values){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"find_by_sql","parameters":[sql, values]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper method to run arbitrary queries against the model's database connection.
*  
*   @param string $sql SQL to execute
*   @param array $values Bind values, if any, for the query
*   @return object A PDOStatement object
*   */
amfphp.services.GroupMember.query = function(onSuccess, onError, sql, values){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"query","parameters":[sql, values]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determines if the specified array is a valid ActiveRecord options array.
*  
*   @param array $array An options array
*   @param bool $throw True to throw an exception if not valid
*   @return boolean True if valid otherwise valse
*   @throws {@link ActiveRecordException} if the array contained any invalid options
*   */
amfphp.services.GroupMember.is_options_hash = function(onSuccess, onError, array, throw){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"is_options_hash","parameters":[array, throw]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a hash containing the names => values of the primary key.
*  
*   @internal This needs to eventually support composite keys.
*   @param mixed $args Primary key value(s)
*   @return array An array in the form array(name => value, ...)
*   */
amfphp.services.GroupMember.pk_conditions = function(onSuccess, onError, args){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"pk_conditions","parameters":[args]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Pulls out the options hash from $array if any.
*  
*   @internal DO NOT remove the reference on $array.
*   @param array &$array An array
*   @return array A valid options array
*   */
amfphp.services.GroupMember.extract_and_validate_options = function(onSuccess, onError, array){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"extract_and_validate_options","parameters":[array]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a JSON representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for json serialization (see {@link Serialization} for valid options)
*   @return string JSON representation of the model
*   */
amfphp.services.GroupMember.to_json = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"to_json","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an XML representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for xml serialization (see {@link Serialization} for valid options)
*   @return string XML representation of the model
*   */
amfphp.services.GroupMember.to_xml = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"to_xml","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*     Returns an CSV representation of this model.
*     Can take optional delimiter and enclosure
*     (defaults are , and double quotes)
*    
*     Ex:
*     <code>
*     ActiveRecord\CsvSerializer::$delimiter=';';
*     ActiveRecord\CsvSerializer::$enclosure='';
*     YourModel::find('first')->to_csv(array('only'=>array('name','level')));
*     returns: Joe,2
*    
*     YourModel::find('first')->to_csv(array('only_header'=>true,'only'=>array('name','level')));
*     returns: name,level
*     </code>
*    
*     @see Serialization
*     @param array $options An array containing options for csv serialization (see {@link Serialization} for valid options)
*     @return string CSV representation of the model
*     */
amfphp.services.GroupMember.to_csv = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"to_csv","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an Array representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for json serialization (see {@link Serialization} for valid options)
*   @return array Array representation of the model
*   */
amfphp.services.GroupMember.to_array = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"to_array","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Executes a block of code inside a database transaction.
*  
*   <code>
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*   });
*   </code>
*  
*   If an exception is thrown inside the closure the transaction will
*   automatically be rolled back. You can also return false from your
*   closure to cause a rollback:
*  
*   <code>
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*     throw new Exception("rollback!");
*   });
*  
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*     return false; # rollback!
*   });
*   </code>
*  
*   @param callable $closure The closure to execute. To cause a rollback have your closure return false or throw an exception.
*   @return boolean True if the transaction was committed, False if rolled back.
*   */
amfphp.services.GroupMember.transaction = function(onSuccess, onError, closure){
	var callData = JSON.stringify({"serviceName":"GroupMember", "methodName":"transaction","parameters":[closure]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Description of settings
*  
*   @author kwaku
*   */
amfphp.services.User = {};


/**  */
amfphp.services.User.getMeta = function(onSuccess, onError, meta_key){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"getMeta","parameters":[meta_key]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Assign a value to an attribute.
*  
*   @param string $name Name of the attribute
*   @param mixed &$value Value of the attribute
*   @return mixed the attribute value
*   */
amfphp.services.User.assign_attribute = function(onSuccess, onError, name, value){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"assign_attribute","parameters":[name, value]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieves an attribute's value or a relationship object based on the name passed. If the attribute
*   accessed is 'id' then it will return the model's primary key no matter what the actual attribute name is
*   for the primary key.
*  
*   @param string $name Name of an attribute
*   @return mixed The value of the attribute
*   @throws {@link UndefinedPropertyException} if name could not be resolved to an attribute, relationship, ...
*   */
amfphp.services.User.read_attribute = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"read_attribute","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Flags an attribute as dirty.
*  
*   @param string $name Attribute name
*   */
amfphp.services.User.flag_dirty = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"flag_dirty","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns hash of attributes that have been modified since loading the model.
*  
*   @return mixed null if no dirty attributes otherwise returns array of dirty attributes.
*   */
amfphp.services.User.dirty_attributes = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"dirty_attributes","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Check if a particular attribute has been modified since loading the model.
*   @param string $attributeName of the attribute
*   @return boolean TRUE if it has been modified.
*   */
amfphp.services.User.attribute_is_dirty = function(onSuccess, onError, attribute){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"attribute_is_dirty","parameters":[attribute]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a copy of the model's attributes hash.
*  
*   @return array A copy of the model's attribute data
*   */
amfphp.services.User.attributes = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"attributes","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieve the primary key name.
*  
*   @param boolean Set to true to return the first value in the pk array only
*   @return string The primary key for the model
*   */
amfphp.services.User.get_primary_key = function(onSuccess, onError, first){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"get_primary_key","parameters":[first]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns the actual attribute name if $name is aliased.
*  
*   @param string $name An attribute name
*   @return string
*   */
amfphp.services.User.get_real_attribute_name = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"get_real_attribute_name","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns array of validator data for this Model.
*  
*   Will return an array looking like:
*  
*   <code>
*   array(
*     'name' => array(
*   array('validator' => 'validates_presence_of'),
*   array('validator' => 'validates_inclusion_of', 'in' => array('Bob','Joe','John')),
*     'password' => array(
*   array('validator' => 'validates_length_of', 'minimum' => 6))
*     )
*   );
*   </code>
*  
*   @return array An array containing validator data for this model.
*   */
amfphp.services.User.get_validation_rules = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"get_validation_rules","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an associative array containing values for all the attributes in $attributes
*  
*   @param array $attributes Array containing attribute names
*   @return array A hash containing $name => $value
*   */
amfphp.services.User.get_values_for = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"get_values_for","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieves the name of the table for this Model.
*  
*   @return string
*   */
amfphp.services.User.table_name = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"table_name","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if the model is in read-only mode.
*  
*   @return boolean
*   */
amfphp.services.User.is_readonly = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"is_readonly","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if the model is a new record.
*  
*   @return boolean
*   */
amfphp.services.User.is_new_record = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"is_new_record","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Flag model as readonly.
*  
*   @param boolean $readonly Set to true to put the model into readonly mode
*   */
amfphp.services.User.readonly = function(onSuccess, onError, readonly){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"readonly","parameters":[readonly]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieve the connection for this model.
*  
*   @return Connection
*   */
amfphp.services.User.connection = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"connection","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Re-establishes the database connection with a new connection.
*  
*   @return Connection
*   */
amfphp.services.User.reestablish_connection = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"reestablish_connection","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns the {@link Table} object for this model.
*  
*   Be sure to call in static scoping: static::table()
*  
*   @return Table
*   */
amfphp.services.User.table = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"table","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Creates a model and saves it to the database.
*  
*   @param array $attributes Array of the models attributes
*   @param boolean $validate True if the validators should be run
*   @param boolean $guard_attributes Set to true to guard protected/non-accessible attributes
*   @return Model
*   */
amfphp.services.User.create = function(onSuccess, onError, attributes, validate, guard_attributes){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"create","parameters":[attributes, validate, guard_attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Save the model to the database.
*  
*   This function will automatically determine if an INSERT or UPDATE needs to occur.
*   If a validation or a callback for this model returns false, then the model will
*   not be saved and this will return false.
*  
*   If saving an existing model only data that has changed will be saved.
*  
*   @param boolean $validate Set to true or false depending on if you want the validators to run or not
*   @return boolean True if the model was saved to the database otherwise false
*   */
amfphp.services.User.save = function(onSuccess, onError, validate){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"save","parameters":[validate]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Deletes records matching conditions in $options
*  
*   Does not instantiate models and therefore does not invoke callbacks
*  
*   Delete all using a hash:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => array('name' => 'Tito')));
*   </code>
*  
*   Delete all using an array:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => array('name = ?', 'Tito')));
*   </code>
*  
*   Delete all using a string:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => 'name = "Tito"));
*   </code>
*  
*   An options array takes the following parameters:
*  
*   <ul>
*   <li><b>conditions:</b> Conditions using a string/hash/array</li>
*   <li><b>limit:</b> Limit number of records to delete (MySQL & Sqlite only)</li>
*   <li><b>order:</b> A SQL fragment for ordering such as: 'name asc', 'id desc, name asc' (MySQL & Sqlite only)</li>
*   </ul>
*  
*   @params array $options
*   return integer Number of rows affected
*   */
amfphp.services.User.delete_all = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"delete_all","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates records using set in $options
*  
*   Does not instantiate models and therefore does not invoke callbacks
*  
*   Update all using a hash:
*  
*   <code>
*   YourModel::update_all(array('set' => array('name' => "Bob")));
*   </code>
*  
*   Update all using a string:
*  
*   <code>
*   YourModel::update_all(array('set' => 'name = "Bob"'));
*   </code>
*  
*   An options array takes the following parameters:
*  
*   <ul>
*   <li><b>set:</b> String/hash of field names and their values to be updated with
*   <li><b>conditions:</b> Conditions using a string/hash/array</li>
*   <li><b>limit:</b> Limit number of records to update (MySQL & Sqlite only)</li>
*   <li><b>order:</b> A SQL fragment for ordering such as: 'name asc', 'id desc, name asc' (MySQL & Sqlite only)</li>
*   </ul>
*  
*   @params array $options
*   return integer Number of rows affected
*   */
amfphp.services.User.update_all = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"update_all","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Deletes this model from the database and returns true if successful.
*  
*   @return boolean
*   */
amfphp.services.User.delete = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"delete","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/**  */
amfphp.services.User.remove_from_cache = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"remove_from_cache","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper that creates an array of values for the primary key(s).
*  
*   @return array An array in the form array(key_name => value, ...)
*   */
amfphp.services.User.values_for_pk = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"values_for_pk","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper to return a hash of values for the specified attributes.
*  
*   @param array $attribute_names Array of attribute names
*   @return array An array in the form array(name => value, ...)
*   */
amfphp.services.User.values_for = function(onSuccess, onError, attribute_names){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"values_for","parameters":[attribute_names]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns true if the model has been modified.
*  
*   @return boolean true if modified
*   */
amfphp.services.User.is_dirty = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"is_dirty","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Run validations on model and returns whether or not model passed validation.
*  
*   @see is_invalid
*   @return boolean
*   */
amfphp.services.User.is_valid = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"is_valid","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Runs validations and returns true if invalid.
*  
*   @see is_valid
*   @return boolean
*   */
amfphp.services.User.is_invalid = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"is_invalid","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates a model's timestamps.
*   */
amfphp.services.User.set_timestamps = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"set_timestamps","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Mass update the model with an array of attribute data and saves to the database.
*  
*   @param array $attributes An attribute data array in the form array(name => value, ...)
*   @return boolean True if successfully updated and saved otherwise false
*   */
amfphp.services.User.update_attributes = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"update_attributes","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates a single attribute and saves the record without going through the normal validation procedure.
*  
*   @param string $name Name of attribute
*   @param mixed $value Value of the attribute
*   @return boolean True if successful otherwise false
*   */
amfphp.services.User.update_attribute = function(onSuccess, onError, name, value){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"update_attribute","parameters":[name, value]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Mass update the model with data from an attributes hash.
*  
*   Unlike update_attributes() this method only updates the model's data
*   but DOES NOT save it to the database.
*  
*   @see update_attributes
*   @param array $attributes An array containing data to update in the form array(name => value, ...)
*   */
amfphp.services.User.set_attributes = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"set_attributes","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Add a model to the given named ($name) relationship.
*  
*   @internal This should <strong>only</strong> be used by eager load
*   @param Model $model
*   @param $name of relationship for this table
*   @return void
*   */
amfphp.services.User.set_relationship_from_eager_load = function(onSuccess, onError, model, name){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"set_relationship_from_eager_load","parameters":[model, name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Reloads the attributes and relationships of this object from the database.
*  
*   @return Model
*   */
amfphp.services.User.reload = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"reload","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Resets the dirty array.
*  
*   @see dirty_attributes
*   */
amfphp.services.User.reset_dirty = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"reset_dirty","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('all').
*  
*   @see find
*   @return array array of records found
*   */
amfphp.services.User.all = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"all","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Get a count of qualifying records.
*  
*   <code>
*   YourModel::count(array('conditions' => 'amount > 3.14159265'));
*   </code>
*  
*   @see find
*   @return int Number of records that matched the query
*   */
amfphp.services.User.count = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"count","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if a record exists.
*  
*   <code>
*   SomeModel::exists(123);
*   SomeModel::exists(array('conditions' => array('id=? and name=?', 123, 'Tito')));
*   SomeModel::exists(array('id' => 123, 'name' => 'Tito'));
*   </code>
*  
*   @see find
*   @return boolean
*   */
amfphp.services.User.exists = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"exists","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('first').
*  
*   @see find
*   @return Model The first matched record or null if not found
*   */
amfphp.services.User.first = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"first","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('last')
*  
*   @see find
*   @return Model The last matched record or null if not found
*   */
amfphp.services.User.last = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"last","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Find records in the database.
*  
*   Finding by the primary key:
*  
*   <code>
*   # queries for the model with id=123
*   YourModel::find(123);
*  
*   # queries for model with id in(1,2,3)
*   YourModel::find(1,2,3);
*  
*   # finding by pk accepts an options array
*   YourModel::find(123,array('order' => 'name desc'));
*   </code>
*  
*   Finding by using a conditions array:
*  
*   <code>
*   YourModel::find('first', array('conditions' => array('name=?','Tito'),
*     'order' => 'name asc'))
*   YourModel::find('all', array('conditions' => 'amount > 3.14159265'));
*   YourModel::find('all', array('conditions' => array('id in(?)', array(1,2,3))));
*   </code>
*  
*   Finding by using a hash:
*  
*   <code>
*   YourModel::find(array('name' => 'Tito', 'id' => 1));
*   YourModel::find('first',array('name' => 'Tito', 'id' => 1));
*   YourModel::find('all',array('name' => 'Tito', 'id' => 1));
*   </code>
*  
*   An options array can take the following parameters:
*  
*   <ul>
*   <li><b>select:</b> A SQL fragment for what fields to return such as: '', 'people.', 'first_name, last_name, id'</li>
*   <li><b>joins:</b> A SQL join fragment such as: 'JOIN roles ON(roles.user_id=user.id)' or a named association on the model</li>
*   <li><b>include:</b> TODO not implemented yet</li>
*   <li><b>conditions:</b> A SQL fragment such as: 'id=1', array('id=1'), array('name=? and id=?','Tito',1), array('name IN(?)', array('Tito','Bob')),
*   array('name' => 'Tito', 'id' => 1)</li>
*   <li><b>limit:</b> Number of records to limit the query to</li>
*   <li><b>offset:</b> The row offset to return results from for the query</li>
*   <li><b>order:</b> A SQL fragment for order such as: 'name asc', 'name asc, id desc'</li>
*   <li><b>readonly:</b> Return all the models in readonly mode</li>
*   <li><b>group:</b> A SQL group by fragment</li>
*   </ul>
*  
*   @throws {@link RecordNotFound} if no options are passed or finding by pk and no records matched
*   @return mixed An array of records found if doing a find_all otherwise a
*     single Model object or null if it wasn't found. NULL is only return when
*     doing a first/last find. If doing an all find and no records matched this
*     will return an empty array.
*   */
amfphp.services.User.find = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"find","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Finder method which will find by a single or array of primary keys for this model.
*  
*   @see find
*   @param array $values An array containing values for the pk
*   @param array $options An options array
*   @return Model
*   @throws {@link RecordNotFound} if a record could not be found
*   */
amfphp.services.User.find_by_pk = function(onSuccess, onError, values, options){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"find_by_pk","parameters":[values, options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Find using a raw SELECT query.
*  
*   <code>
*   YourModel::find_by_sql("SELECT  FROM people WHERE name=?",array('Tito'));
*   YourModel::find_by_sql("SELECT  FROM people WHERE name='Tito'");
*   </code>
*  
*   @param string $sql The raw SELECT query
*   @param array $values An array of values for any parameters that needs to be bound
*   @return array An array of models
*   */
amfphp.services.User.find_by_sql = function(onSuccess, onError, sql, values){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"find_by_sql","parameters":[sql, values]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper method to run arbitrary queries against the model's database connection.
*  
*   @param string $sql SQL to execute
*   @param array $values Bind values, if any, for the query
*   @return object A PDOStatement object
*   */
amfphp.services.User.query = function(onSuccess, onError, sql, values){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"query","parameters":[sql, values]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determines if the specified array is a valid ActiveRecord options array.
*  
*   @param array $array An options array
*   @param bool $throw True to throw an exception if not valid
*   @return boolean True if valid otherwise valse
*   @throws {@link ActiveRecordException} if the array contained any invalid options
*   */
amfphp.services.User.is_options_hash = function(onSuccess, onError, array, throw){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"is_options_hash","parameters":[array, throw]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a hash containing the names => values of the primary key.
*  
*   @internal This needs to eventually support composite keys.
*   @param mixed $args Primary key value(s)
*   @return array An array in the form array(name => value, ...)
*   */
amfphp.services.User.pk_conditions = function(onSuccess, onError, args){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"pk_conditions","parameters":[args]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Pulls out the options hash from $array if any.
*  
*   @internal DO NOT remove the reference on $array.
*   @param array &$array An array
*   @return array A valid options array
*   */
amfphp.services.User.extract_and_validate_options = function(onSuccess, onError, array){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"extract_and_validate_options","parameters":[array]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a JSON representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for json serialization (see {@link Serialization} for valid options)
*   @return string JSON representation of the model
*   */
amfphp.services.User.to_json = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"to_json","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an XML representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for xml serialization (see {@link Serialization} for valid options)
*   @return string XML representation of the model
*   */
amfphp.services.User.to_xml = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"to_xml","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*     Returns an CSV representation of this model.
*     Can take optional delimiter and enclosure
*     (defaults are , and double quotes)
*    
*     Ex:
*     <code>
*     ActiveRecord\CsvSerializer::$delimiter=';';
*     ActiveRecord\CsvSerializer::$enclosure='';
*     YourModel::find('first')->to_csv(array('only'=>array('name','level')));
*     returns: Joe,2
*    
*     YourModel::find('first')->to_csv(array('only_header'=>true,'only'=>array('name','level')));
*     returns: name,level
*     </code>
*    
*     @see Serialization
*     @param array $options An array containing options for csv serialization (see {@link Serialization} for valid options)
*     @return string CSV representation of the model
*     */
amfphp.services.User.to_csv = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"to_csv","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an Array representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for json serialization (see {@link Serialization} for valid options)
*   @return array Array representation of the model
*   */
amfphp.services.User.to_array = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"to_array","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Executes a block of code inside a database transaction.
*  
*   <code>
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*   });
*   </code>
*  
*   If an exception is thrown inside the closure the transaction will
*   automatically be rolled back. You can also return false from your
*   closure to cause a rollback:
*  
*   <code>
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*     throw new Exception("rollback!");
*   });
*  
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*     return false; # rollback!
*   });
*   </code>
*  
*   @param callable $closure The closure to execute. To cause a rollback have your closure return false or throw an exception.
*   @return boolean True if the transaction was committed, False if rolled back.
*   */
amfphp.services.User.transaction = function(onSuccess, onError, closure){
	var callData = JSON.stringify({"serviceName":"User", "methodName":"transaction","parameters":[closure]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Description of settings
*  
*   @author kwaku
*   */
amfphp.services.UserMetum = {};


/**  */
amfphp.services.UserMetum.getMeta = function(onSuccess, onError, contact_id, meta_key){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"getMeta","parameters":[contact_id, meta_key]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Assign a value to an attribute.
*  
*   @param string $name Name of the attribute
*   @param mixed &$value Value of the attribute
*   @return mixed the attribute value
*   */
amfphp.services.UserMetum.assign_attribute = function(onSuccess, onError, name, value){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"assign_attribute","parameters":[name, value]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieves an attribute's value or a relationship object based on the name passed. If the attribute
*   accessed is 'id' then it will return the model's primary key no matter what the actual attribute name is
*   for the primary key.
*  
*   @param string $name Name of an attribute
*   @return mixed The value of the attribute
*   @throws {@link UndefinedPropertyException} if name could not be resolved to an attribute, relationship, ...
*   */
amfphp.services.UserMetum.read_attribute = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"read_attribute","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Flags an attribute as dirty.
*  
*   @param string $name Attribute name
*   */
amfphp.services.UserMetum.flag_dirty = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"flag_dirty","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns hash of attributes that have been modified since loading the model.
*  
*   @return mixed null if no dirty attributes otherwise returns array of dirty attributes.
*   */
amfphp.services.UserMetum.dirty_attributes = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"dirty_attributes","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Check if a particular attribute has been modified since loading the model.
*   @param string $attributeName of the attribute
*   @return boolean TRUE if it has been modified.
*   */
amfphp.services.UserMetum.attribute_is_dirty = function(onSuccess, onError, attribute){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"attribute_is_dirty","parameters":[attribute]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a copy of the model's attributes hash.
*  
*   @return array A copy of the model's attribute data
*   */
amfphp.services.UserMetum.attributes = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"attributes","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieve the primary key name.
*  
*   @param boolean Set to true to return the first value in the pk array only
*   @return string The primary key for the model
*   */
amfphp.services.UserMetum.get_primary_key = function(onSuccess, onError, first){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"get_primary_key","parameters":[first]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns the actual attribute name if $name is aliased.
*  
*   @param string $name An attribute name
*   @return string
*   */
amfphp.services.UserMetum.get_real_attribute_name = function(onSuccess, onError, name){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"get_real_attribute_name","parameters":[name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns array of validator data for this Model.
*  
*   Will return an array looking like:
*  
*   <code>
*   array(
*     'name' => array(
*   array('validator' => 'validates_presence_of'),
*   array('validator' => 'validates_inclusion_of', 'in' => array('Bob','Joe','John')),
*     'password' => array(
*   array('validator' => 'validates_length_of', 'minimum' => 6))
*     )
*   );
*   </code>
*  
*   @return array An array containing validator data for this model.
*   */
amfphp.services.UserMetum.get_validation_rules = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"get_validation_rules","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an associative array containing values for all the attributes in $attributes
*  
*   @param array $attributes Array containing attribute names
*   @return array A hash containing $name => $value
*   */
amfphp.services.UserMetum.get_values_for = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"get_values_for","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieves the name of the table for this Model.
*  
*   @return string
*   */
amfphp.services.UserMetum.table_name = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"table_name","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if the model is in read-only mode.
*  
*   @return boolean
*   */
amfphp.services.UserMetum.is_readonly = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"is_readonly","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if the model is a new record.
*  
*   @return boolean
*   */
amfphp.services.UserMetum.is_new_record = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"is_new_record","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Flag model as readonly.
*  
*   @param boolean $readonly Set to true to put the model into readonly mode
*   */
amfphp.services.UserMetum.readonly = function(onSuccess, onError, readonly){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"readonly","parameters":[readonly]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Retrieve the connection for this model.
*  
*   @return Connection
*   */
amfphp.services.UserMetum.connection = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"connection","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Re-establishes the database connection with a new connection.
*  
*   @return Connection
*   */
amfphp.services.UserMetum.reestablish_connection = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"reestablish_connection","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns the {@link Table} object for this model.
*  
*   Be sure to call in static scoping: static::table()
*  
*   @return Table
*   */
amfphp.services.UserMetum.table = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"table","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Creates a model and saves it to the database.
*  
*   @param array $attributes Array of the models attributes
*   @param boolean $validate True if the validators should be run
*   @param boolean $guard_attributes Set to true to guard protected/non-accessible attributes
*   @return Model
*   */
amfphp.services.UserMetum.create = function(onSuccess, onError, attributes, validate, guard_attributes){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"create","parameters":[attributes, validate, guard_attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Save the model to the database.
*  
*   This function will automatically determine if an INSERT or UPDATE needs to occur.
*   If a validation or a callback for this model returns false, then the model will
*   not be saved and this will return false.
*  
*   If saving an existing model only data that has changed will be saved.
*  
*   @param boolean $validate Set to true or false depending on if you want the validators to run or not
*   @return boolean True if the model was saved to the database otherwise false
*   */
amfphp.services.UserMetum.save = function(onSuccess, onError, validate){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"save","parameters":[validate]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Deletes records matching conditions in $options
*  
*   Does not instantiate models and therefore does not invoke callbacks
*  
*   Delete all using a hash:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => array('name' => 'Tito')));
*   </code>
*  
*   Delete all using an array:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => array('name = ?', 'Tito')));
*   </code>
*  
*   Delete all using a string:
*  
*   <code>
*   YourModel::delete_all(array('conditions' => 'name = "Tito"));
*   </code>
*  
*   An options array takes the following parameters:
*  
*   <ul>
*   <li><b>conditions:</b> Conditions using a string/hash/array</li>
*   <li><b>limit:</b> Limit number of records to delete (MySQL & Sqlite only)</li>
*   <li><b>order:</b> A SQL fragment for ordering such as: 'name asc', 'id desc, name asc' (MySQL & Sqlite only)</li>
*   </ul>
*  
*   @params array $options
*   return integer Number of rows affected
*   */
amfphp.services.UserMetum.delete_all = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"delete_all","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates records using set in $options
*  
*   Does not instantiate models and therefore does not invoke callbacks
*  
*   Update all using a hash:
*  
*   <code>
*   YourModel::update_all(array('set' => array('name' => "Bob")));
*   </code>
*  
*   Update all using a string:
*  
*   <code>
*   YourModel::update_all(array('set' => 'name = "Bob"'));
*   </code>
*  
*   An options array takes the following parameters:
*  
*   <ul>
*   <li><b>set:</b> String/hash of field names and their values to be updated with
*   <li><b>conditions:</b> Conditions using a string/hash/array</li>
*   <li><b>limit:</b> Limit number of records to update (MySQL & Sqlite only)</li>
*   <li><b>order:</b> A SQL fragment for ordering such as: 'name asc', 'id desc, name asc' (MySQL & Sqlite only)</li>
*   </ul>
*  
*   @params array $options
*   return integer Number of rows affected
*   */
amfphp.services.UserMetum.update_all = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"update_all","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Deletes this model from the database and returns true if successful.
*  
*   @return boolean
*   */
amfphp.services.UserMetum.delete = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"delete","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/**  */
amfphp.services.UserMetum.remove_from_cache = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"remove_from_cache","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper that creates an array of values for the primary key(s).
*  
*   @return array An array in the form array(key_name => value, ...)
*   */
amfphp.services.UserMetum.values_for_pk = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"values_for_pk","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper to return a hash of values for the specified attributes.
*  
*   @param array $attribute_names Array of attribute names
*   @return array An array in the form array(name => value, ...)
*   */
amfphp.services.UserMetum.values_for = function(onSuccess, onError, attribute_names){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"values_for","parameters":[attribute_names]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns true if the model has been modified.
*  
*   @return boolean true if modified
*   */
amfphp.services.UserMetum.is_dirty = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"is_dirty","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Run validations on model and returns whether or not model passed validation.
*  
*   @see is_invalid
*   @return boolean
*   */
amfphp.services.UserMetum.is_valid = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"is_valid","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Runs validations and returns true if invalid.
*  
*   @see is_valid
*   @return boolean
*   */
amfphp.services.UserMetum.is_invalid = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"is_invalid","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates a model's timestamps.
*   */
amfphp.services.UserMetum.set_timestamps = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"set_timestamps","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Mass update the model with an array of attribute data and saves to the database.
*  
*   @param array $attributes An attribute data array in the form array(name => value, ...)
*   @return boolean True if successfully updated and saved otherwise false
*   */
amfphp.services.UserMetum.update_attributes = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"update_attributes","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Updates a single attribute and saves the record without going through the normal validation procedure.
*  
*   @param string $name Name of attribute
*   @param mixed $value Value of the attribute
*   @return boolean True if successful otherwise false
*   */
amfphp.services.UserMetum.update_attribute = function(onSuccess, onError, name, value){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"update_attribute","parameters":[name, value]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Mass update the model with data from an attributes hash.
*  
*   Unlike update_attributes() this method only updates the model's data
*   but DOES NOT save it to the database.
*  
*   @see update_attributes
*   @param array $attributes An array containing data to update in the form array(name => value, ...)
*   */
amfphp.services.UserMetum.set_attributes = function(onSuccess, onError, attributes){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"set_attributes","parameters":[attributes]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Add a model to the given named ($name) relationship.
*  
*   @internal This should <strong>only</strong> be used by eager load
*   @param Model $model
*   @param $name of relationship for this table
*   @return void
*   */
amfphp.services.UserMetum.set_relationship_from_eager_load = function(onSuccess, onError, model, name){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"set_relationship_from_eager_load","parameters":[model, name]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Reloads the attributes and relationships of this object from the database.
*  
*   @return Model
*   */
amfphp.services.UserMetum.reload = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"reload","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Resets the dirty array.
*  
*   @see dirty_attributes
*   */
amfphp.services.UserMetum.reset_dirty = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"reset_dirty","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('all').
*  
*   @see find
*   @return array array of records found
*   */
amfphp.services.UserMetum.all = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"all","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Get a count of qualifying records.
*  
*   <code>
*   YourModel::count(array('conditions' => 'amount > 3.14159265'));
*   </code>
*  
*   @see find
*   @return int Number of records that matched the query
*   */
amfphp.services.UserMetum.count = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"count","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determine if a record exists.
*  
*   <code>
*   SomeModel::exists(123);
*   SomeModel::exists(array('conditions' => array('id=? and name=?', 123, 'Tito')));
*   SomeModel::exists(array('id' => 123, 'name' => 'Tito'));
*   </code>
*  
*   @see find
*   @return boolean
*   */
amfphp.services.UserMetum.exists = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"exists","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('first').
*  
*   @see find
*   @return Model The first matched record or null if not found
*   */
amfphp.services.UserMetum.first = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"first","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Alias for self::find('last')
*  
*   @see find
*   @return Model The last matched record or null if not found
*   */
amfphp.services.UserMetum.last = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"last","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Find records in the database.
*  
*   Finding by the primary key:
*  
*   <code>
*   # queries for the model with id=123
*   YourModel::find(123);
*  
*   # queries for model with id in(1,2,3)
*   YourModel::find(1,2,3);
*  
*   # finding by pk accepts an options array
*   YourModel::find(123,array('order' => 'name desc'));
*   </code>
*  
*   Finding by using a conditions array:
*  
*   <code>
*   YourModel::find('first', array('conditions' => array('name=?','Tito'),
*     'order' => 'name asc'))
*   YourModel::find('all', array('conditions' => 'amount > 3.14159265'));
*   YourModel::find('all', array('conditions' => array('id in(?)', array(1,2,3))));
*   </code>
*  
*   Finding by using a hash:
*  
*   <code>
*   YourModel::find(array('name' => 'Tito', 'id' => 1));
*   YourModel::find('first',array('name' => 'Tito', 'id' => 1));
*   YourModel::find('all',array('name' => 'Tito', 'id' => 1));
*   </code>
*  
*   An options array can take the following parameters:
*  
*   <ul>
*   <li><b>select:</b> A SQL fragment for what fields to return such as: '', 'people.', 'first_name, last_name, id'</li>
*   <li><b>joins:</b> A SQL join fragment such as: 'JOIN roles ON(roles.user_id=user.id)' or a named association on the model</li>
*   <li><b>include:</b> TODO not implemented yet</li>
*   <li><b>conditions:</b> A SQL fragment such as: 'id=1', array('id=1'), array('name=? and id=?','Tito',1), array('name IN(?)', array('Tito','Bob')),
*   array('name' => 'Tito', 'id' => 1)</li>
*   <li><b>limit:</b> Number of records to limit the query to</li>
*   <li><b>offset:</b> The row offset to return results from for the query</li>
*   <li><b>order:</b> A SQL fragment for order such as: 'name asc', 'name asc, id desc'</li>
*   <li><b>readonly:</b> Return all the models in readonly mode</li>
*   <li><b>group:</b> A SQL group by fragment</li>
*   </ul>
*  
*   @throws {@link RecordNotFound} if no options are passed or finding by pk and no records matched
*   @return mixed An array of records found if doing a find_all otherwise a
*     single Model object or null if it wasn't found. NULL is only return when
*     doing a first/last find. If doing an all find and no records matched this
*     will return an empty array.
*   */
amfphp.services.UserMetum.find = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"find","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Finder method which will find by a single or array of primary keys for this model.
*  
*   @see find
*   @param array $values An array containing values for the pk
*   @param array $options An options array
*   @return Model
*   @throws {@link RecordNotFound} if a record could not be found
*   */
amfphp.services.UserMetum.find_by_pk = function(onSuccess, onError, values, options){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"find_by_pk","parameters":[values, options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Find using a raw SELECT query.
*  
*   <code>
*   YourModel::find_by_sql("SELECT  FROM people WHERE name=?",array('Tito'));
*   YourModel::find_by_sql("SELECT  FROM people WHERE name='Tito'");
*   </code>
*  
*   @param string $sql The raw SELECT query
*   @param array $values An array of values for any parameters that needs to be bound
*   @return array An array of models
*   */
amfphp.services.UserMetum.find_by_sql = function(onSuccess, onError, sql, values){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"find_by_sql","parameters":[sql, values]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Helper method to run arbitrary queries against the model's database connection.
*  
*   @param string $sql SQL to execute
*   @param array $values Bind values, if any, for the query
*   @return object A PDOStatement object
*   */
amfphp.services.UserMetum.query = function(onSuccess, onError, sql, values){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"query","parameters":[sql, values]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Determines if the specified array is a valid ActiveRecord options array.
*  
*   @param array $array An options array
*   @param bool $throw True to throw an exception if not valid
*   @return boolean True if valid otherwise valse
*   @throws {@link ActiveRecordException} if the array contained any invalid options
*   */
amfphp.services.UserMetum.is_options_hash = function(onSuccess, onError, array, throw){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"is_options_hash","parameters":[array, throw]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a hash containing the names => values of the primary key.
*  
*   @internal This needs to eventually support composite keys.
*   @param mixed $args Primary key value(s)
*   @return array An array in the form array(name => value, ...)
*   */
amfphp.services.UserMetum.pk_conditions = function(onSuccess, onError, args){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"pk_conditions","parameters":[args]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Pulls out the options hash from $array if any.
*  
*   @internal DO NOT remove the reference on $array.
*   @param array &$array An array
*   @return array A valid options array
*   */
amfphp.services.UserMetum.extract_and_validate_options = function(onSuccess, onError, array){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"extract_and_validate_options","parameters":[array]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns a JSON representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for json serialization (see {@link Serialization} for valid options)
*   @return string JSON representation of the model
*   */
amfphp.services.UserMetum.to_json = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"to_json","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an XML representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for xml serialization (see {@link Serialization} for valid options)
*   @return string XML representation of the model
*   */
amfphp.services.UserMetum.to_xml = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"to_xml","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*     Returns an CSV representation of this model.
*     Can take optional delimiter and enclosure
*     (defaults are , and double quotes)
*    
*     Ex:
*     <code>
*     ActiveRecord\CsvSerializer::$delimiter=';';
*     ActiveRecord\CsvSerializer::$enclosure='';
*     YourModel::find('first')->to_csv(array('only'=>array('name','level')));
*     returns: Joe,2
*    
*     YourModel::find('first')->to_csv(array('only_header'=>true,'only'=>array('name','level')));
*     returns: name,level
*     </code>
*    
*     @see Serialization
*     @param array $options An array containing options for csv serialization (see {@link Serialization} for valid options)
*     @return string CSV representation of the model
*     */
amfphp.services.UserMetum.to_csv = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"to_csv","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Returns an Array representation of this model.
*  
*   @see Serialization
*   @param array $options An array containing options for json serialization (see {@link Serialization} for valid options)
*   @return array Array representation of the model
*   */
amfphp.services.UserMetum.to_array = function(onSuccess, onError, options){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"to_array","parameters":[options]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Executes a block of code inside a database transaction.
*  
*   <code>
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*   });
*   </code>
*  
*   If an exception is thrown inside the closure the transaction will
*   automatically be rolled back. You can also return false from your
*   closure to cause a rollback:
*  
*   <code>
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*     throw new Exception("rollback!");
*   });
*  
*   YourModel::transaction(function()
*   {
*     YourModel::create(array("name" => "blah"));
*     return false; # rollback!
*   });
*   </code>
*  
*   @param callable $closure The closure to execute. To cause a rollback have your closure return false or throw an exception.
*   @return boolean True if the transaction was committed, False if rolled back.
*   */
amfphp.services.UserMetum.transaction = function(onSuccess, onError, closure){
	var callData = JSON.stringify({"serviceName":"UserMetum", "methodName":"transaction","parameters":[closure]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Authentication and user administration service
*  
*   @package Amfphp_Examples_Authentication
*   @author Sven Dens
*   */
amfphp.services.AuthenticationService = {};


/** 
*   sign in
*   @param string $username
*   @param string $password
*   @return boolean
*   */
amfphp.services.AuthenticationService.signIn = function(onSuccess, onError, username, password){
	var callData = JSON.stringify({"serviceName":"AuthenticationService", "methodName":"signIn","parameters":[username, password]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   sign out function
*   */
amfphp.services.AuthenticationService.signOut = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"AuthenticationService", "methodName":"signOut","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   an example service for the pizza examples
*   @package Amfphp_Examples_ExampleService
*   @author Ariel Sommeria-klein
*   */
amfphp.services.PizzaService = {};


/** 
*   get a pizza!
*   @return string
*   */
amfphp.services.PizzaService.getPizza = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"PizzaService", "methodName":"getPizza","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   Authentication and user administration service
*  
*   @package Amfphp_Examples_Authentication
*   @author Sven Dens
*   */
amfphp.services.UserService = {};


/** 
*   
*   function to create a new user to authenticate with AMFPHP
*   @param string $firstName
*   @param string $lastName
*   @param string $userName
*   @param string $password
*   @param int $userRoleId
*   @return stdClass
*   @throws Exception
*   */
amfphp.services.UserService.createUser = function(onSuccess, onError, firstName, lastName, userName, password, userRoleId){
	var callData = JSON.stringify({"serviceName":"UserService", "methodName":"createUser","parameters":[firstName, lastName, userName, password, userRoleId]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   function to update an existing AMFPHP authentication user
*   @param string $firstName
*   @param string $lastName
*   @param string $userName
*   @param string $password
*   @param int $userRoleId
*   @param int $id
*   @return type
*   @throws Exception
*   */
amfphp.services.UserService.updateUser = function(onSuccess, onError, firstName, lastName, userName, password, userRoleId, id){
	var callData = JSON.stringify({"serviceName":"UserService", "methodName":"updateUser","parameters":[firstName, lastName, userName, password, userRoleId, id]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   function to delete an AMFPHP authentication user
*  
*   @param int $id
*   */
amfphp.services.UserService.deleteUser = function(onSuccess, onError, id){
	var callData = JSON.stringify({"serviceName":"UserService", "methodName":"deleteUser","parameters":[id]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   get users
*   @return array
*   */
amfphp.services.UserService.getUsers = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"UserService", "methodName":"getUsers","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   an example service for typed objects
*   @package Amfphp_Examples_ExampleService
*   @author Ariel Sommeria-klein
*   */
amfphp.services.VoService = {};


/** 
*   This method expects a UserVo1 object. So amfPHP must receive a typed UserVo1 object, and the VoConverter plugin
*   must find the UserVo1 class in its value object folders
*   @param UserVo1 $user example: {"_explicitType":"UserVo1", "name":"ariel", "status":"bla"}
*   @return UserVo1
*   */
amfphp.services.VoService.receiveAndReturnUserVo1 = function(onSuccess, onError, user){
	var callData = JSON.stringify({"serviceName":"VoService", "methodName":"receiveAndReturnUserVo1","parameters":[user]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   This method accepts any object. The idea here is that you send an object that is typed(see client example projects)
*   and it will be returned. This allows you to use typing on the client side without needing to create
*   corresponding PHP VO classes. If you do this exclusively, you can disable the VoConverter plugin,
*   which will increase performance.
*   amfPHP does this by using the reserved '_explicitType' marker on anonymous PHP objects.
*   
*   @param stdClass $user example:{"_explicitType":"UserVo2", "name":"joe", "age":56, "status":"cool"}
*   @return stdClass 
*   */
amfphp.services.VoService.receiveAndReturnUserVo2 = function(onSuccess, onError, user){
	var callData = JSON.stringify({"serviceName":"VoService", "methodName":"receiveAndReturnUserVo2","parameters":[user]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*   simple service for testing namespace support
*  
*   @package Amfphp_Examples_ExampleService
*   @author Ariel Sommeria-klein
*   */
amfphp.services.NamespaceTestService = {};


/** 
*   bla function, dummy
*   @return string 
*   */
amfphp.services.NamespaceTestService.bla = function(onSuccess, onError){
	var callData = JSON.stringify({"serviceName":"NamespaceTestService", "methodName":"bla","parameters":[]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
/** 
*  
*   @param type $vo example:  {"_explicitType":"NamespaceTestVo", "dummyData":"blabla"}
*   @return type 
*   */
amfphp.services.NamespaceTestService.useVo = function(onSuccess, onError, vo){
	var callData = JSON.stringify({"serviceName":"NamespaceTestService", "methodName":"useVo","parameters":[vo]});
	    $.post(amfphp.entryPointUrl, callData, onSuccess)
	    	.error(onError);
	
}
